package com.example.dognutrition;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class UserMain extends AppCompatActivity {

    Button profilebtn,viewProducts,Cart,OrderHostory,clips;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        int userId = getIntent().getIntExtra("USER_ID", -1);
        profilebtn=findViewById(R.id.button11);
        Cart=findViewById(R.id.button14);



        profilebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(UserMain.this,ManageProfile.class);
                intent1.putExtra("USER_ID", userId);
                startActivity(intent1);
            }
        });

        viewProducts=findViewById(R.id.button9);
        viewProducts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2=new Intent(UserMain.this,ViewProducts.class);
                startActivity(intent2);

            }
        });

        Cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3=new Intent(UserMain.this,ViewCart.class);
                startActivity(intent3);
            }
        });

        OrderHostory=findViewById(R.id.button10);
        clips=findViewById(R.id.button21);
        clips.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newintent=new Intent(UserMain.this,ClipList.class);
                startActivity(newintent);
            }
        });
        OrderHostory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent4=new Intent(UserMain.this,UserOrderList.class);
                intent4.putExtra("USER_ID", userId);

                startActivity(intent4);

            }
        });
    }
}