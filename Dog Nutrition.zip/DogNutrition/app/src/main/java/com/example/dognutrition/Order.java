package com.example.dognutrition;

public class Order {
    private int orderId;
    private String orderDate;
    private String orderStatus;
    private String customerName; // New field
    private String customerPhone; // New field

    public Order(int orderId, String orderDate, String orderStatus, String customerName, String customerPhone) {
        this.orderId = orderId;
        this.orderDate = orderDate;
        this.orderStatus = orderStatus;
        this.customerName = customerName;
        this.customerPhone = customerPhone;
    }


    public int getOrderId() {
        return orderId;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }
}
