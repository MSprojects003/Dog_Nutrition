package com.example.dognutrition;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class CartAdapter extends BaseAdapter {

    private Context context;
    private List<CartItem> cartItems;

    public CartAdapter(Context context, List<CartItem> cartItems) {
        this.context = context;
        this.cartItems = cartItems;
    }

    @Override
    public int getCount() {
        return cartItems.size();
    }

    @Override
    public Object getItem(int position) {
        return cartItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.cart_list, parent, false);
        }

        CartItem currentItem = (CartItem) getItem(position);


        ImageView imageView = convertView.findViewById(R.id.productImage);
        TextView nameTextView = convertView.findViewById(R.id.productName);
        TextView priceTextView = convertView.findViewById(R.id.productPrice);
        TextView quantityTextView = convertView.findViewById(R.id.productQuantity);
        TextView totalPriceTextView = convertView.findViewById(R.id.textView14);
        ImageButton deleteButton = convertView.findViewById(R.id.imageButton2);


        Bitmap productImage = currentItem.getProductImage();
        if (productImage != null) {
            imageView.setImageBitmap(productImage);
        } else {
            imageView.setImageResource(R.drawable.ic_launcher_foreground);
        }


        nameTextView.setText(currentItem.getProductName());
        priceTextView.setText("Rs. " + currentItem.getProductPrice());
        quantityTextView.setText("Quantity: " + currentItem.getQuantity());


        double price = currentItem.getProductPrice();
        double totalPrice = price * currentItem.getQuantity();
        totalPriceTextView.setText("Total: Rs. " + totalPrice);


        deleteButton.setOnClickListener(v -> {

            cartItems.remove(position);


            CartItem itemToRemove = currentItem;
            CartSingleton.getInstance().removeCartItem(itemToRemove.getProductId());


            notifyDataSetChanged();


            if (context instanceof ViewCart) {
                ((ViewCart) context).calculateTotalPrice();
            }
        });

        return convertView;
    }
}
