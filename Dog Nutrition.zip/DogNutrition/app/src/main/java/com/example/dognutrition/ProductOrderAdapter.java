package com.example.dognutrition;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class ProductOrderAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<HashMap<String, Object>> productList;

    public ProductOrderAdapter(Context context, ArrayList<HashMap<String, Object>> productList) {
        this.context = context;
        this.productList = productList;
    }

    @Override
    public int getCount() {
        return productList.size();
    }

    @Override
    public Object getItem(int position) {
        return productList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.product_order_list_view, parent, false);
        }


        ImageView productImageView = convertView.findViewById(R.id.imageView13);
        TextView productNameTextView = convertView.findViewById(R.id.textView22);
        TextView productPriceTextView = convertView.findViewById(R.id.textView23);
        TextView quantityTextView = convertView.findViewById(R.id.textView24);
        TextView totalTextView = convertView.findViewById(R.id.textView25);


        HashMap<String, Object> product = productList.get(position);


        productNameTextView.setText((String) product.get("product_name"));
        productPriceTextView.setText((String) product.get("product_price"));
        quantityTextView.setText((String) product.get("quantity"));
        totalTextView.setText((String) product.get("total"));


        productImageView.setImageBitmap((Bitmap) product.get("product_image"));

        return convertView;
    }
}

