package com.example.dognutrition;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class UserOrderList extends AppCompatActivity {
    private ListView orderListView;
    private DBHelper dbHelper;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_order_list);

        userId = getIntent().getIntExtra("USER_ID", -1);
        orderListView = findViewById(R.id.orderListView);
        dbHelper = new DBHelper(this);

        loadOrders();
    }

    private void loadOrders() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT O_ID AS _id, O_DATE, STATUS FROM ORDERS WHERE UID = ?",
                new String[]{String.valueOf(userId)});

        String[] from = {"_id", "O_DATE", "STATUS"};
        int[] to = {R.id.textView10, R.id.textView12, R.id.textView13};

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this,
                R.layout.admin_order_list,
                cursor,
                from,
                to,
                0) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView dateTextView = view.findViewById(R.id.textView12);

                Cursor cursor = (Cursor) getItem(position);
                String originalDate = cursor.getString(cursor.getColumnIndex("O_DATE"));
                String formattedDate = formatDate(originalDate);
                dateTextView.setText(formattedDate);

                return view;
            }
        };

        orderListView.setAdapter(adapter);

        // Set an item click listener for the ListView
        orderListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the order ID from the clicked item
                Cursor cursor = (Cursor) adapter.getItem(position);
                int orderId = cursor.getInt(cursor.getColumnIndex("_id"));

                // Create an Intent to start UserOrderDetails
                Intent intent = new Intent(UserOrderList.this, UserOrderDetails.class);
                intent.putExtra("ORDER_ID", orderId);
                startActivity(intent);
            }
        });
    }

    private String formatDate(String originalDate) {
        try {
            SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date date = originalFormat.parse(originalDate);
            SimpleDateFormat newFormat = new SimpleDateFormat("MMM, dd", Locale.getDefault());
            return newFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return originalDate;
        }
    }
}
