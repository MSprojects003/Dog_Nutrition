package com.example.dognutrition;

public class Product {
    private int id;
    private String name;
    private double price;
    private byte[] image;
    private int quantity;
    private double total;


    public Product(int id, String name, double price, byte[] image, int quantity) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.image = image;
        this.quantity = quantity;
        this.total = price * quantity;
    }


    public int getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public byte[] getImage() { return image; }
    public int getQuantity() { return quantity; }
    public double getTotal() { return total; }
}
