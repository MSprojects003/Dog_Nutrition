package com.example.dognutrition;

public class Clip {
    private int id;
    private String name;
    private byte[] thumbnail;

    public Clip(int id, String name, byte[] thumbnail) {
        this.id = id;
        this.name = name;
        this.thumbnail = thumbnail;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public byte[] getThumbnail() {
        return thumbnail;
    }
}
