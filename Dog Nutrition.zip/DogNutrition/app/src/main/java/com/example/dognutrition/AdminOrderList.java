package com.example.dognutrition;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.dognutrition.Order;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class
AdminOrderList extends AppCompatActivity {

    DBHelper db;
    ListView orderListView;
    OrderAdapter orderAdapter;
    ArrayList<Order> orders = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_order_list);


        db = new DBHelper(this);
        orderListView = findViewById(R.id.ListView);


        Cursor cursor = db.getAllOrders();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int orderId = cursor.getInt(cursor.getColumnIndexOrThrow("order_id"));
                String orderDate = cursor.getString(cursor.getColumnIndexOrThrow("order_date"));
                String orderStatus = cursor.getString(cursor.getColumnIndexOrThrow("order_status"));
                String customerName = cursor.getString(cursor.getColumnIndexOrThrow("customer_name"));
                String customerPhone = cursor.getString(cursor.getColumnIndexOrThrow("customer_phone"));


                SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                SimpleDateFormat outputFormat = new SimpleDateFormat("MMM d", Locale.getDefault());
                String formattedDate = "";
                try {
                    Date date = inputFormat.parse(orderDate);
                    if (date != null) {
                        formattedDate = outputFormat.format(date);
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }


                Order order = new Order(orderId, formattedDate, orderStatus, customerName, customerPhone);
                orders.add(order);
            } while (cursor.moveToNext());

            cursor.close();
        } else {
            Toast.makeText(this, "No orders found", Toast.LENGTH_SHORT).show();
        }


        orderAdapter = new OrderAdapter(this, orders);
        orderListView.setAdapter(orderAdapter);


        orderListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Order selectedOrder = orders.get(position);


                Intent intent = new Intent(AdminOrderList.this, AdminOrderDetails.class);


                intent.putExtra("ORDER_ID", selectedOrder.getOrderId());


                startActivity(intent);
            }
        });
    }
}
