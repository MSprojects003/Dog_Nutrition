package com.example.dognutrition;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

public class Admin_view_product extends AppCompatActivity {
    private DBHelper dbHelper;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_view_product);

        dbHelper = new DBHelper(this);
        listView = findViewById(R.id.listview1);

        Cursor cursor = dbHelper.getProductDetails();
        CustomAdapter adapter = new CustomAdapter(this, cursor);
        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get selected product ID
                Cursor clickedItemCursor = (Cursor) parent.getItemAtPosition(position);
                long productId = clickedItemCursor.getLong(clickedItemCursor.getColumnIndex("P_ID"));

                // Start the delete activity
                Intent intent = new Intent(Admin_view_product.this, DeleteProduct.class);
                intent.putExtra("PRODUCT_ID", productId);
                startActivity(intent);
            }
        });
    }
}
