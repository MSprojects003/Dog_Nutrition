package com.example.dognutrition;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.util.ArrayList;

public class AdminViewClip extends AppCompatActivity {

    private static final String TAG = "AdminViewClip";
    private DBHelper dbHelper;
    private TextView clipNameTextView;
    private VideoView videoView;
    private ImageView imageViewThumbnail;
    private ImageButton buttonPlayVideo;
    private ListView listViewClips;
    private ClipAdapter clipAdapter;
    private ArrayList<Clip> clipList;
    private String videoPath;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_view_clip);

        // Initialize views
        dbHelper = new DBHelper(this);
        clipNameTextView = findViewById(R.id.textViewClipName);
        videoView = findViewById(R.id.videoView);
        imageViewThumbnail = findViewById(R.id.imageViewThumbnail);
        buttonPlayVideo = findViewById(R.id.buttonPlayVideo);
        listViewClips = findViewById(R.id.ListViewClips);

        // Get the clip ID passed from the previous activity
        long clipId = getIntent().getLongExtra("CLIP_ID", -1);
        Log.d(TAG, "Received clip ID: " + clipId);

        if (clipId != -1) {
            loadClipDetails(clipId);
            loadOtherClips(clipId);
            addPlayButtonListener();
        } else {
            Toast.makeText(this, "Invalid clip ID.", Toast.LENGTH_SHORT).show();
        }

        // Set up item click listener for the ListView
        listViewClips.setOnItemClickListener((parent, view, position, id) -> {
            Clip clickedClip = (Clip) parent.getItemAtPosition(position);
            long newClipId = clickedClip.getId();

            Intent intent = new Intent(AdminViewClip.this, AdminViewClip.class);
            intent.putExtra("CLIP_ID", newClipId);
            startActivity(intent);
            finish(); // Close current activity to avoid stacking activities
        });
    }

    private void loadClipDetails(long clipId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query("CLIP", null, "C_ID = ?", new String[]{String.valueOf(clipId)}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            // Retrieve clip name
            String clipName = cursor.getString(cursor.getColumnIndex("C_NAME"));

            // Retrieve thumbnail as byte array
            byte[] thumbnail = cursor.getBlob(cursor.getColumnIndex("C_THUMB"));

            // Retrieve video path as String
            videoPath = cursor.getString(cursor.getColumnIndex("C_VIDEO"));

            // Log the video path for debugging
            Log.d(TAG, "Video path: " + videoPath);

            // Use the retrieved data
            clipNameTextView.setText(clipName);
            imageViewThumbnail.setImageBitmap(BitmapFactory.decodeByteArray(thumbnail, 0, thumbnail.length));

            cursor.close();
        } else {
            Toast.makeText(this, "Clip not found.", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadOtherClips(long excludeClipId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM CLIP WHERE C_ID != ?", new String[]{String.valueOf(excludeClipId)});

        clipList = new ArrayList<>();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex("C_ID"));
                String name = cursor.getString(cursor.getColumnIndex("C_NAME"));
                byte[] thumbnail = cursor.getBlob(cursor.getColumnIndex("C_THUMB"));

                Clip clip = new Clip(id, name, thumbnail);
                clipList.add(clip);
                Log.d(TAG, "Loaded clip ID: " + id + ", Name: " + name);
            } while (cursor.moveToNext());
            cursor.close();
        } else {
            Log.e(TAG, "No other clips found.");
        }

        clipAdapter = new ClipAdapter(this, clipList);
        listViewClips.setAdapter(clipAdapter);
    }

    private void addPlayButtonListener() {
        buttonPlayVideo.setOnClickListener(v -> {
            // Check if videoPath is not null or empty
            if (videoPath == null || videoPath.isEmpty()) {
                Toast.makeText(this, "Video path is invalid.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if the video file exists
            File videoFile = new File(videoPath);
            if (!videoFile.exists()) {
                Log.e(TAG, "Video file does not exist at path: " + videoPath);
                Toast.makeText(this, "Video file not found: " + videoPath, Toast.LENGTH_SHORT).show();
                return;
            }

            // Set visibility of UI elements
            imageViewThumbnail.setVisibility(View.GONE);
            buttonPlayVideo.setVisibility(View.GONE);
            videoView.setVisibility(View.VISIBLE);

            // Set the video path and start playing
            videoView.setVideoURI(Uri.fromFile(videoFile));
            videoView.setOnPreparedListener(mp -> videoView.start());

            // Set up listeners for completion and error
            videoView.setOnCompletionListener(mp -> {
                videoView.setVisibility(View.GONE);
                imageViewThumbnail.setVisibility(View.VISIBLE);
                buttonPlayVideo.setVisibility(View.VISIBLE);
            });

            videoView.setOnErrorListener((mp, what, extra) -> {
                String errorMessage = "Error playing video: ";
                switch (what) {
                    case MediaPlayer.MEDIA_ERROR_UNKNOWN:
                        errorMessage += "Unknown error occurred.";
                        break;
                    case MediaPlayer.MEDIA_ERROR_SERVER_DIED:
                        errorMessage += "Media server died.";
                        break;
                    default:
                        errorMessage += "Unrecognized error. What: " + what + ", Extra: " + extra;
                        break;
                }
                Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show();
                Log.e(TAG, errorMessage + " Extra code: " + extra);
                videoView.setVisibility(View.GONE);
                imageViewThumbnail.setVisibility(View.VISIBLE);
                buttonPlayVideo.setVisibility(View.VISIBLE);
                return true; // Indicate the error was handled
            });
        });
    }

}
