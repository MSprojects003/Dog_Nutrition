package com.example.dognutrition;

import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class UserOrderDetails extends AppCompatActivity {

    private DBHelper dbHelper;
    private TextView orderDateTextView, TotalPrice, orderStatusTextView, orderIdTextView;
    private ListView listView;
    private int orderId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_order_details);

        dbHelper = new DBHelper(this);


        TotalPrice = findViewById(R.id.textView11);
        orderDateTextView = findViewById(R.id.textView18);
        orderStatusTextView = findViewById(R.id.textView19);
        orderIdTextView = findViewById(R.id.textView16);
        listView = findViewById(R.id.ListView);


        orderId = getIntent().getIntExtra("ORDER_ID", -1);

        if (orderId != -1) {
            loadOrderDetails(orderId);
            loadOrderProducts(orderId);
        } else {
            Log.e("UserOrderDetails", "Invalid order ID.");
        }
    }

    private void loadOrderDetails(int orderId) {

        Cursor cursor = dbHelper.getOrderDetailsWithProducts(orderId);
        if (cursor != null && cursor.moveToFirst()) {
            String orderDate = cursor.getString(cursor.getColumnIndex("order_date"));
            String orderStatus = "Status    : " + cursor.getString(cursor.getColumnIndex("order_status"));


            String formattedDate = formatDate(orderDate);


            orderDateTextView.setText("Order Date: " + formattedDate);
            orderStatusTextView.setText(orderStatus);


            orderIdTextView.setText("Order ID: " + orderId);

            cursor.close();
        } else {
            Log.e("UserOrderDetails", "No data found for orderId: " + orderId);
        }
    }

    private String formatDate(String dateString) {
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        SimpleDateFormat outputFormat = new SimpleDateFormat("MMM, dd", Locale.getDefault());
        String formattedDate = "";

        try {
            Date date = inputFormat.parse(dateString);
            formattedDate = outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return formattedDate;
    }

    private void loadOrderProducts(int orderId) {
        Cursor cursor = dbHelper.getOrderDetailsWithProducts(orderId);
        ArrayList<HashMap<String, Object>> productList = new ArrayList<>();
        double totalp = 0.0;
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String productName = cursor.getString(cursor.getColumnIndex("product_name"));
                int quantity = cursor.getInt(cursor.getColumnIndex("QUANTITY"));
                double total = cursor.getDouble(cursor.getColumnIndex("L_TOTAL"));
                double productPrice = cursor.getDouble(cursor.getColumnIndex("product_price"));
                byte[] imageBytes = cursor.getBlob(cursor.getColumnIndex("product_image"));
                Bitmap productImage = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);


                HashMap<String, Object> product = new HashMap<>();
                product.put("product_name", productName);
                product.put("quantity", String.valueOf(quantity));
                product.put("total", String.format("%.2f", total));
                product.put("product_price", String.format("%.2f", productPrice));
                product.put("product_image", productImage);


                productList.add(product);

                totalp += total;
            } while (cursor.moveToNext());

            cursor.close();


            ProductOrderAdapter adapter = new ProductOrderAdapter(this, productList);
            listView.setAdapter(adapter);

            TotalPrice.setText("Total Price: " + String.format("%.2f", totalp));
        } else {
            Log.e("UserOrderDetails", "No products found for the given orderId: " + orderId);
        }
    }
}
