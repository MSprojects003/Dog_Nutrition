package com.example.dognutrition;

import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ProductDetails extends AppCompatActivity {

    DBHelper db;
    ImageView productImage;
    TextView productName, productPrice, productDescription, productBrand, productType, countTextView;
    Button addButton, minusButton, addToCartButton;
    int count = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);


        db = new DBHelper(this);
        productImage = findViewById(R.id.productImage);
        productName = findViewById(R.id.productName);
        productPrice = findViewById(R.id.productPrice);
        productDescription = findViewById(R.id.productDescription);
        productBrand = findViewById(R.id.textView4);
        productType = findViewById(R.id.textView6);
        countTextView = findViewById(R.id.textView7);
        addButton = findViewById(R.id.button16);
        minusButton = findViewById(R.id.button13);
        addToCartButton = findViewById(R.id.button17);


        countTextView.setText(String.valueOf(count));


        int productId = getIntent().getIntExtra("PRODUCT_ID", -1);


        if (productId != -1) {
            loadProductDetails(productId);
        } else {
            Toast.makeText(this, "Invalid Product ID.", Toast.LENGTH_SHORT).show();
        }


        addButton.setOnClickListener(v -> {
            count++;
            countTextView.setText(String.valueOf(count));
        });

        minusButton.setOnClickListener(v -> {
            if (count > 1) {
                count--;
                countTextView.setText(String.valueOf(count));
            }
        });

        addToCartButton.setOnClickListener(v -> {
            if (productId != -1) {
                CartSingleton.getInstance().addItemToCart(productId, count);
                Toast.makeText(this, "Added " + count + " item(s) to cart", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Invalid Product ID.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadProductDetails(int productId) {
        // Query the database for the product details using the productId
        Cursor cursor = db.getProductDetailsById(productId);

        if (cursor != null && cursor.moveToFirst()) {
            // Extract data from the cursor
            String name = cursor.getString(cursor.getColumnIndex("P_name"));
            String price = cursor.getString(cursor.getColumnIndex("P_price"));
            String description = cursor.getString(cursor.getColumnIndex("P_des")); // Assuming there is a description column
            String brand = cursor.getString(cursor.getColumnIndex("P_brand")); // Assuming there is a brand column
            String type = cursor.getString(cursor.getColumnIndex("P_type")); // Assuming there is a type column
            byte[] image = cursor.getBlob(cursor.getColumnIndex("P_image"));

            // Set the data to the UI components
            productName.setText(name);
            productPrice.setText("Rs. " + price);
            productDescription.setText(description);
            productBrand.setText(brand);
            productType.setText(type);

            // Decode and set the image
            if (image != null) {
                Bitmap bitmap = BitmapFactory.decodeByteArray(image, 0, image.length);
                productImage.setImageBitmap(bitmap);
            } else {
                productImage.setImageResource(R.drawable.ic_launcher_background); // Optional placeholder
            }

            cursor.close();
        } else {
            Toast.makeText(this, "Product not found.", Toast.LENGTH_SHORT).show();
        }
    }
}
