package com.example.dognutrition;

import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Date;

public class ViewCart extends AppCompatActivity {

    DBHelper db;
    ListView cartListView;
    CartAdapter cartAdapter;
    ArrayList<CartItem> cartItems = new ArrayList<>();
    TextView totalPriceTextView;
    Button buyButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_cart);


        db = new DBHelper(this);
        cartListView = findViewById(R.id.cartListView);
        totalPriceTextView = findViewById(R.id.textView11);
        buyButton = findViewById(R.id.button15);


        HashMap<Integer, Integer> cartMap = CartSingleton.getInstance().getCartItems();


        for (HashMap.Entry<Integer, Integer> entry : cartMap.entrySet()) {
            int productId = entry.getKey();
            int quantity = entry.getValue();


            Cursor cursor = db.getProductDetailsById(productId);
            if (cursor != null && cursor.moveToFirst()) {
                String name = cursor.getString(cursor.getColumnIndex("P_name"));
                double price = cursor.getDouble(cursor.getColumnIndex("P_price"));
                String description = cursor.getString(cursor.getColumnIndex("P_des"));
                String brand = cursor.getString(cursor.getColumnIndex("P_brand"));
                String type = cursor.getString(cursor.getColumnIndex("P_type"));
                byte[] image = cursor.getBlob(cursor.getColumnIndex("P_image"));

                Bitmap bitmap = null;
                if (image != null) {
                    bitmap = BitmapFactory.decodeByteArray(image, 0, image.length);
                }


                CartItem cartItem = new CartItem(productId, name, price, description, brand, type, bitmap, quantity);
                cartItems.add(cartItem);
            }
            if (cursor != null) {
                cursor.close();
            }
        }


        cartAdapter = new CartAdapter(this, cartItems);
        cartListView.setAdapter(cartAdapter);


        calculateTotalPrice();


        buyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                placeOrder();
            }
        });
    }

    public void calculateTotalPrice() {
        double totalPrice = 0;


        for (CartItem item : cartItems) {
            double price = item.getProductPrice();
            totalPrice += price * item.getQuantity();
        }


        totalPriceTextView.setText("Total: Rs. " + totalPrice);
    }

    private void placeOrder() {

        double totalPrice = 0;
        for (CartItem item : cartItems) {
            double price = item.getProductPrice();
            totalPrice += price * item.getQuantity();
        }


        int userId = 1;


        String orderDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());


        long orderId = db.addOrder(orderDate, String.valueOf(totalPrice), userId);
        if (orderId != -1) {

            boolean itemsAdded = db.addOrderItems(orderId, cartItems);
            if (itemsAdded) {
                Toast.makeText(this, "Order placed successfully!", Toast.LENGTH_SHORT).show();

                CartSingleton.getInstance().getCartItems().clear();
                finish();
            } else {
                Toast.makeText(this, "Failed to add order items.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Failed to place order.", Toast.LENGTH_SHORT).show();
        }
    }
}
