package com.example.dognutrition;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DeleteProduct extends AppCompatActivity {
    private DBHelper dbHelper;
    private long productId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_product);

        dbHelper = new DBHelper(this);


        Intent intent = getIntent();
        productId = intent.getLongExtra("PRODUCT_ID", -1);

        Button deleteButton = findViewById(R.id.button7);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean isDeleted = dbHelper.deleteProduct(productId);
                if (isDeleted) {
                    Toast.makeText(DeleteProduct.this, "Product deleted successfully", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(DeleteProduct.this, "Failed to delete product", Toast.LENGTH_SHORT).show();
                }
            }
        });
        Button editButton = findViewById(R.id.button8);
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(DeleteProduct.this, EditProduct.class);
                intent.putExtra("PRODUCT_ID", productId);
                startActivity(intent);
            }
        });



    }
}
