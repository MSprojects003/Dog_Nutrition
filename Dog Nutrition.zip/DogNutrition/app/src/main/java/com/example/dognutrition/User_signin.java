package com.example.dognutrition;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class User_signin extends AppCompatActivity {
    TextView register;
    EditText email, paswd;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_signin);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        email = findViewById(R.id.email);
        Button buttonlogin = findViewById(R.id.login_button);
        paswd = findViewById(R.id.paswd);
        register = findViewById(R.id.textView3);

        DBHelper dbHelper = new DBHelper(this);
        db = dbHelper.getReadableDatabase();

        buttonlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Email = email.getText().toString();
                String Password = paswd.getText().toString();

                if (Email.equals("") || Password.equals("")) {
                    Toast.makeText(User_signin.this, "Please Fill missing Field", Toast.LENGTH_SHORT).show();
                } else {
                    Cursor cursor = db.rawQuery("SELECT * FROM User WHERE U_NAME = ? AND U_PASSWORD = ?", new String[]{Email, Password});
                    if (cursor.moveToFirst()) {

                        Toast.makeText(User_signin.this, "Login successful", Toast.LENGTH_SHORT).show();
                        @SuppressLint("Range") int userID = cursor.getInt(cursor.getColumnIndex("U_ID"));

                        Intent intent2 = new Intent(User_signin.this, UserMain.class);
                        intent2.putExtra("USER_ID", userID);
                        startActivity(intent2);
                    } else {

                        Toast.makeText(User_signin.this, "Invalid email or password", Toast.LENGTH_SHORT).show();
                    }
                    cursor.close();
                }
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(User_signin.this, Register.class);
                startActivity(intent1);
            }
        });
    }
}
