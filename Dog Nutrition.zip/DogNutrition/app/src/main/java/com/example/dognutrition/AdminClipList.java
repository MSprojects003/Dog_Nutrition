package com.example.dognutrition;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.BaseAdapter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import androidx.appcompat.app.AppCompatActivity;

public class AdminClipList extends AppCompatActivity {
    private DBHelper dbHelper;
    private ListView listView;
    private Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_clip_list);

        dbHelper = new DBHelper(this);
        listView = findViewById(R.id.ListViewClips);

        loadClips();


        listView.setOnItemClickListener((parent, view, position, id) -> {
            // Get the selected clip ID
            cursor.moveToPosition(position);
            long clipId = cursor.getLong(cursor.getColumnIndex("C_ID"));

            // Create an intent to start the AdminViewClip activity
            Intent intent = new Intent(AdminClipList.this, AdminViewClip.class);
            intent.putExtra("CLIP_ID", clipId); // Pass the clip ID
            startActivity(intent); // Start the activity
        });
    }

    private void loadClips() {
        cursor = dbHelper.getAllClips(); // Fetch all clips from the database
        ClipAdapter adapter = new ClipAdapter(cursor);
        listView.setAdapter(adapter);
    }

    private class ClipAdapter extends BaseAdapter {
        private Cursor cursor;

        ClipAdapter(Cursor cursor) {
            this.cursor = cursor;
        }

        @Override
        public int getCount() {
            return cursor.getCount();
        }

        @Override
        public Object getItem(int position) {
            cursor.moveToPosition(position);
            return cursor;
        }

        @Override
        public long getItemId(int position) {
            cursor.moveToPosition(position);
            return cursor.getLong(cursor.getColumnIndex("C_ID"));
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = getLayoutInflater().inflate(R.layout.clip_layout, parent, false);
            }

            cursor.moveToPosition(position);

            TextView clipNameTextView = convertView.findViewById(R.id.clipName);
            ImageView clipThumbImageView = convertView.findViewById(R.id.clipThumbnail);

            String clipName = cursor.getString(cursor.getColumnIndex("C_NAME"));
            byte[] thumbBytes = cursor.getBlob(cursor.getColumnIndex("C_THUMB"));
            Bitmap thumbnail = BitmapFactory.decodeByteArray(thumbBytes, 0, thumbBytes.length);

            clipNameTextView.setText(clipName);
            clipThumbImageView.setImageBitmap(thumbnail);

            return convertView;
        }
    }
}
