package com.example.dognutrition;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ManageProfile extends AppCompatActivity {

    Button cancelbtn, updateButton;
    EditText emailEditText, phoneEditText, passwordEditText, confirmPasswordEditText;
    DBHelper db;
    int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_manage_profile);


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        emailEditText = findViewById(R.id.Email);
        phoneEditText = findViewById(R.id.Phone);
        passwordEditText = findViewById(R.id.Password);
        confirmPasswordEditText = findViewById(R.id.cpassword);



        updateButton = findViewById(R.id.updatepro);


        userId = getIntent().getIntExtra("USER_ID", -1);


        db = new DBHelper(this);


        if (userId != -1) {
            Cursor cursor = db.getReadableDatabase().rawQuery("SELECT * FROM User WHERE U_ID = ?", new String[]{String.valueOf(userId)});
            if (cursor.moveToFirst()) {
                @SuppressLint("Range") String email = cursor.getString(cursor.getColumnIndex("U_NAME"));
                @SuppressLint("Range") String phone = cursor.getString(cursor.getColumnIndex("U_PHONE"));
                @SuppressLint("Range") String password = cursor.getString(cursor.getColumnIndex("U_PASSWORD"));


                emailEditText.setText(email);
                phoneEditText.setText(phone);
                passwordEditText.setText(password);
                confirmPasswordEditText.setText(password);
            }
            cursor.close();
        }




        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateUserDetails();
            }
        });
    }

    private void updateUserDetails() {
        String email = emailEditText.getText().toString();
        String phone = phoneEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        String confirmPassword = confirmPasswordEditText.getText().toString();

        // Validate inputs
        if (email.isEmpty() || phone.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(ManageProfile.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(ManageProfile.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        // Update the user's details in the database
        ContentValues contentValues = new ContentValues();
        contentValues.put("U_NAME", email);
        contentValues.put("U_PHONE", phone);
        contentValues.put("U_PASSWORD", password);

        SQLiteDatabase dbWritable = db.getWritableDatabase();
        long result = dbWritable.update("User", contentValues, "U_ID = ?", new String[]{String.valueOf(userId)});

        if (result != -1) {
            Toast.makeText(ManageProfile.this, "Profile updated successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(ManageProfile.this, "Profile update failed", Toast.LENGTH_SHORT).show();
        }
    }
}
