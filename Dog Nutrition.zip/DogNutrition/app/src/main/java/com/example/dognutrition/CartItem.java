package com.example.dognutrition;

import android.graphics.Bitmap;

public class CartItem {

    private final int productId;
    private final String productName;
    private final double productPrice; // Changed from String to double
    private final String productDescription;
    private final String productBrand;
    private final String productType;
    private final Bitmap productImage;
    private final int quantity;

    public CartItem(int productId, String productName, double productPrice, String productDescription,
                    String productBrand, String productType, Bitmap productImage, int quantity) {
        this.productId = productId;
        this.productName = productName;
        this.productPrice = productPrice;
        this.productDescription = productDescription;
        this.productBrand = productBrand;
        this.productType = productType;
        this.productImage = productImage;
        this.quantity = quantity;
    }


    public int getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public double getProductPrice() { // Changed to return double
        return productPrice;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public String getProductBrand() {
        return productBrand;
    }

    public String getProductType() {
        return productType;
    }

    public Bitmap getProductImage() {
        return productImage;
    }

    public int getQuantity() {
        return quantity;
    }
}
