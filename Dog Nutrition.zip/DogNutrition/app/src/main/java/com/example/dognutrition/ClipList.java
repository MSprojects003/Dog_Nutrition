package com.example.dognutrition;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ClipList extends AppCompatActivity implements ClipListAdapter.OnClipClickListener {

    private RecyclerView recyclerView;
    private ClipListAdapter clipListAdapter;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clip_list); // Use your layout file

        recyclerView = findViewById(R.id.recyclerViewClips);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new DBHelper(this);
        List<ClipData> clipDataList = new ArrayList<>();


        Cursor cursor = dbHelper.getAllClips();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                int clipId = cursor.getInt(cursor.getColumnIndex("C_ID")); // Ensure you're getting the clip ID
                String clipTitle = cursor.getString(cursor.getColumnIndex("C_NAME"));
                byte[] thumbnail = cursor.getBlob(cursor.getColumnIndex("C_THUMB"));
                clipDataList.add(new ClipData(clipId, clipTitle, thumbnail)); // Pass the ID to ClipData
            }
            cursor.close();
        }


        clipListAdapter = new ClipListAdapter(clipDataList, this);
        recyclerView.setAdapter(clipListAdapter);
    }

    @Override
    public void onClipClick(int clipId) {
        Log.d("ClipList", "Clicked Clip ID: " + clipId);
        Intent intent = new Intent(ClipList.this, AdminViewClip.class);
        intent.putExtra("CLIP_ID", (long) clipId); // Cast to Long
        startActivity(intent);
    }}
