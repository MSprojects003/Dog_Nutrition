package com.example.dognutrition;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class Addclip extends AppCompatActivity {

    private EditText editTextClipName;
    private ImageView imageViewThumbnail, imageViewVideo;
    private Button buttonAddVideo;
    private Bitmap thumbnailBitmap;
    private String videoPath;

    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int PICK_VIDEO_REQUEST = 2;

    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addclip);

        // Initialize views
        editTextClipName = findViewById(R.id.editTextClipName);
        imageViewThumbnail = findViewById(R.id.imageViewThumbnail);
        imageViewVideo = findViewById(R.id.imageViewVideo);
        buttonAddVideo = findViewById(R.id.buttonAddVideo);

        dbHelper = new DBHelper(this);

        // Handle thumbnail selection
        imageViewThumbnail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImageChooser();
            }
        });

        // Handle video selection
        imageViewVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openVideoChooser();
            }
        });


        buttonAddVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addClipToDatabase();
            }
        });
    }


    private void openImageChooser() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    // Method to open the video chooser
    private void openVideoChooser() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_VIDEO_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            Uri selectedUri = data.getData();
            if (requestCode == PICK_IMAGE_REQUEST) {
                try {
                    thumbnailBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedUri);
                    imageViewThumbnail.setImageBitmap(thumbnailBitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (requestCode == PICK_VIDEO_REQUEST) {
                // Get the video path as a String
                videoPath = getVideoPathFromUri(selectedUri);
                imageViewVideo.setImageBitmap(getVideoThumbnail(selectedUri));
            }
        }
    }


    private String getVideoPathFromUri(Uri uri) {
        String[] projection = {MediaStore.Video.Media.DATA};
        Cursor cursor = getContentResolver().query(uri, projection, null, null, null);
        if (cursor != null) {
            int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA);
            cursor.moveToFirst();
            String path = cursor.getString(columnIndex);
            cursor.close();
            return path;
        }
        return null;
    }


    private Bitmap getVideoThumbnail(Uri uri) {
        return MediaStore.Video.Thumbnails.getThumbnail(
                getContentResolver(),
                Long.parseLong(uri.getLastPathSegment()),
                MediaStore.Video.Thumbnails.MINI_KIND,
                null);
    }


    private byte[] getBytesFromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
        return stream.toByteArray();
    }


    private void addClipToDatabase() {
        String clipName = editTextClipName.getText().toString();

        if (clipName.isEmpty() || thumbnailBitmap == null || videoPath == null) {
            Toast.makeText(this, "Please provide a name, thumbnail, and video.", Toast.LENGTH_SHORT).show();
            return;
        }

        byte[] thumbnail = getBytesFromBitmap(thumbnailBitmap);


        dbHelper.addClip(clipName, thumbnail, videoPath);
        Toast.makeText(this, "Clip added successfully!", Toast.LENGTH_SHORT).show();
        finish();
    }
}
