package com.example.dognutrition;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class ClipAdapter extends ArrayAdapter<Clip> {
    private final Context context;
    private final ArrayList<Clip> clips;

    public ClipAdapter(Context context, ArrayList<Clip> clips) {
        super(context, R.layout.clip_layout, clips);
        this.context = context;
        this.clips = clips;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.clip_layout, parent, false);

        TextView clipName = rowView.findViewById(R.id.clipName);
        ImageView clipThumbnail = rowView.findViewById(R.id.clipThumbnail);

        Clip clip = clips.get(position);
        clipName.setText(clip.getName());
        clipThumbnail.setImageBitmap(BitmapFactory.decodeByteArray(clip.getThumbnail(), 0, clip.getThumbnail().length));

        return rowView;
    }
}
