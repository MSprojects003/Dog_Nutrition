package com.example.dognutrition;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class EditProduct extends AppCompatActivity {
    private DBHelper dbHelper;
    private long productId;
    private EditText editProductName, editProductType, editBrand, editPrice, editDescription;
    private ImageButton imageButtonSelect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_product);

        dbHelper = new DBHelper(this);
        productId = getIntent().getLongExtra("PRODUCT_ID", -1);

        // Initialize EditText fields
        editProductName = findViewById(R.id.editProductName1);
        editProductType = findViewById(R.id.editProductType1);
        editBrand = findViewById(R.id.editBrand1);
        editPrice = findViewById(R.id.editPrice1);
        editDescription = findViewById(R.id.editDescription1);
        imageButtonSelect = findViewById(R.id.imageButtonSelect1);


        loadProductDetails();


        Button editButton = findViewById(R.id.buttonSubmit1);
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dbHelper.updateProduct(productId, editProductName.getText().toString(), editProductType.getText().toString(),
                        editBrand.getText().toString(), editPrice.getText().toString(), editDescription.getText().toString());
                Toast.makeText(EditProduct.this, "Product updated successfully", Toast.LENGTH_SHORT).show();
                finish();
            }
        });


        imageButtonSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectImageFromGallery();
            }
        });
    }

    @SuppressLint("Range")
    private void loadProductDetails() {
        Cursor cursor = dbHelper.getProductDetailsById((int) productId);
        if (cursor != null && cursor.moveToFirst()) {
            editProductName.setText(cursor.getString(cursor.getColumnIndex("P_name")));
            editProductType.setText(cursor.getString(cursor.getColumnIndex("P_type")));
            editBrand.setText(cursor.getString(cursor.getColumnIndex("P_brand")));
            editPrice.setText(cursor.getString(cursor.getColumnIndex("P_price")));
            editDescription.setText(cursor.getString(cursor.getColumnIndex("P_des")));


            byte[] imageBytes = cursor.getBlob(cursor.getColumnIndex(DBHelper.COLUMN_IMAGE)); // Use COLUMN_IMAGE
            if (imageBytes != null) {
                Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
                imageButtonSelect.setImageBitmap(bitmap);
            }

            cursor.close();
        }
    }

    private void selectImageFromGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            Uri selectedImageUri = data.getData();
            if (selectedImageUri != null) {
                try {

                    InputStream inputStream = getContentResolver().openInputStream(selectedImageUri);
                    byte[] imageBytes = getBytes(inputStream);

                    dbHelper.updateProductImage(productId, imageBytes);

                    Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
                    imageButtonSelect.setImageBitmap(bitmap);
                    Toast.makeText(this, "Image updated successfully", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Failed to update image", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];
        int len;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }
}
