package com.example.dognutrition;

import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import android.database.sqlite.SQLiteDatabase;

import com.example.dognutrition.DBHelper;

public class Add_products extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;

    private EditText editProductName, editProductType, editBrand, editPrice, editDescription;
    private ImageButton imageButtonSelect;
    private Uri imageUri;
    private DBHelper dbHelper;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_products);

        // Initialize Views
        editProductName = findViewById(R.id.editProductName);
        editProductType = findViewById(R.id.editProductType);
        editBrand = findViewById(R.id.editBrand);
        editPrice = findViewById(R.id.editPrice);
        editDescription = findViewById(R.id.editDescription);
        imageButtonSelect = findViewById(R.id.imageButtonSelect);

        // Initialize Database Helper
        dbHelper = new DBHelper(this);
        db = dbHelper.getWritableDatabase();

        // Set onClickListener for image selection
        imageButtonSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();

            imageButtonSelect.setImageURI(imageUri);
        }
    }

    public void insertProduct(View view) {
        String Pname = editProductName.getText().toString();
        String Ptype = editProductType.getText().toString();
        String Pbrand = editBrand.getText().toString();
        String Pprice = editPrice.getText().toString();
        String Pdes = editDescription.getText().toString();

        // Validate inputs
        if (Pname.isEmpty() || Ptype.isEmpty() || Pbrand.isEmpty() || Pprice.isEmpty() || Pdes.isEmpty() || imageUri == null) {
            Toast.makeText(this, "Please fill all fields and select an image", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            InputStream inputStream = getContentResolver().openInputStream(imageUri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
            byte[] imageByteArray = getBytesFromBitmap(bitmap);

            // Insert data into the database
            ContentValues values = new ContentValues();
            values.put("P_name", Pname);
            values.put("P_type", Ptype);
            values.put("P_brand", Pbrand);
            values.put("P_price", Pprice);
            values.put("P_des", Pdes);
            values.put("P_image", imageByteArray);

            long result = db.insert("Product", null, values);

            if (result != -1) {
                Toast.makeText(this, "Product added successfully", Toast.LENGTH_SHORT).show();
                // Optionally clear input fields
                clearFields();
            } else {
                Toast.makeText(this, "Failed to add product", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private byte[] getBytesFromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        return stream.toByteArray();
    }

    private void clearFields() {
        editProductName.setText("");
        editProductType.setText("");
        editBrand.setText("");
        editPrice.setText("");
        editDescription.setText("");
        imageButtonSelect.setImageResource(android.R.drawable.ic_menu_camera); // Reset the image button
    }
}
