package com.example.dognutrition;

import java.util.HashMap;

public class CartSingleton {
    private static CartSingleton instance;
    private final HashMap<Integer, Integer> cartItems;

    private CartSingleton() {
        cartItems = new HashMap<>();
    }

    public static synchronized CartSingleton getInstance() {
        if (instance == null) {
            instance = new CartSingleton();
        }
        return instance;
    }

    public void addItemToCart(int productId, int quantity) {
        if (cartItems.containsKey(productId)) {
            cartItems.put(productId, cartItems.get(productId) + quantity);
        } else {
            cartItems.put(productId, quantity);
        }
    }

    public void removeCartItem(int productId) {

        cartItems.remove(productId);
    }

    public HashMap<Integer, Integer> getCartItems() {
        return cartItems;
    }
}
