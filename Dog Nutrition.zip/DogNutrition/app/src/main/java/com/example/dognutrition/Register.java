package com.example.dognutrition;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Register extends AppCompatActivity {

    TextView Email, phone, Password, cpassword;
    Button button1;
    String email, Phone, password, cpaswd;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Email = findViewById(R.id.Email);
        phone = findViewById(R.id.Phone);
        Password = findViewById(R.id.Password);
        cpassword = findViewById(R.id.cpassword);

        DBHelper dbHelper = new DBHelper(this);
        db = dbHelper.getWritableDatabase();

        button1 = findViewById(R.id.Reg_button);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email = Email.getText().toString();
                Phone = phone.getText().toString();
                password = Password.getText().toString();
                cpaswd = cpassword.getText().toString();

                if (email.equals("") || Phone.equals("") || password.equals("") || cpaswd.equals("")) {
                    Toast.makeText(Register.this, "Fill in All Fields", Toast.LENGTH_SHORT).show();
                } else {
                    if (password.equals(cpaswd)) {

                        Cursor cursor = db.rawQuery("SELECT * FROM User WHERE U_NAME = ?", new String[]{email});
                        if (cursor.moveToFirst()) {

                            Toast.makeText(Register.this, "Email already registered", Toast.LENGTH_SHORT).show();
                        } else {

                            ContentValues values = new ContentValues();
                            values.put("U_NAME", email);
                            values.put("U_PHONE", Phone);
                            values.put("U_PASSWORD", password);

                            long result = db.insert("User", null, values);
                            if (result != -1) {
                                Toast.makeText(Register.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(Register.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                        cursor.close();
                    } else {
                        Toast.makeText(Register.this, "Passwords Don't Match!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }
}
