package com.example.dognutrition;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    public static final String COLUMN_IMAGE = "P_image";
    private static final String TABLE_PRODUCT = "Product";
    public static final String COLUMN_NAME = "P_name";

    public DBHelper(@Nullable Context context) {
        super(context, "Dogcare", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Product (" +
                "P_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "P_name VARCHAR(40), " +
                "P_price REAL, " +
                "P_brand VARCHAR(40), " +
                "P_type VARCHAR(40), " +
                "P_des TEXT, " +
                "P_image BLOB" +
                ")");

        db.execSQL("CREATE TABLE User (" +
                "U_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "U_NAME VARCHAR(50)," +
                "U_PHONE VARCHAR(15)," +
                "U_PASSWORD VARCHAR(20)" +
                ")");

        db.execSQL("CREATE TABLE ORDERS (" +
                "O_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "O_DATE VARCHAR(50)," +
                "TOTAL VARCHAR(15)," +
                "UID INTEGER," +
                "STATUS TEXT," +
                "FOREIGN KEY (UID) REFERENCES User(U_ID)" +
                ")");

        db.execSQL("CREATE TABLE ORDER_LIST (" +
                "OL_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "O_ID INTEGER," +
                "PID INTEGER," +
                "PRICE REAL," +
                "L_TOTAL REAL," +
                "QUANTITY INTEGER," +
                "FOREIGN KEY (O_ID) REFERENCES ORDERS(O_ID)," +
                "FOREIGN KEY (PID) REFERENCES Product(P_ID)" +
                ")");

        db.execSQL("CREATE TABLE CLIP ("+
                "C_ID INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "C_NAME VARCHAR(30),"+
                "C_THUMB BLOB,"+
                "C_VIDEO TEXT "+
                ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Product");
        db.execSQL("DROP TABLE IF EXISTS User");
        db.execSQL("DROP TABLE IF EXISTS ORDERS");
        db.execSQL("DROP TABLE IF EXISTS ORDER_LIST");
        db.execSQL("DROP TABLE IF EXISTS CLIP");
        onCreate(db);
    }

    public Cursor getUserDetails(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM User WHERE U_ID = ?", new String[]{String.valueOf(userId)});
    }

    public Cursor getProductDetails() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM Product ORDER BY P_ID DESC", null);
    }

    public boolean deleteProduct(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete("Product", "P_ID=?", new String[]{String.valueOf(id)});
        return result > 0;
    }

    public Cursor getProductDetailsById(int productId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_PRODUCT, null, "P_ID = ?", new String[]{String.valueOf(productId)}, null, null, null);
    }

    public void updateProduct(long productId, String name, String type, String brand, String price, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put("P_type", type);
        values.put("P_brand", brand);
        values.put("P_price", price);
        values.put("P_des", description);
        db.update(TABLE_PRODUCT, values, "P_ID = ?", new String[]{String.valueOf(productId)});
    }

    public void updateProductImage(long productId, byte[] image) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_IMAGE, image);
        db.update(TABLE_PRODUCT, values, "P_ID = ?", new String[]{String.valueOf(productId)});
    }

    public Cursor getProductById(int productId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM Product WHERE P_ID = ?", new String[]{String.valueOf(productId)});
    }

    public long addOrder(String orderDate, String total, int userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("O_DATE", orderDate);
        values.put("TOTAL", total);
        values.put("UID", userId);
        values.put("STATUS", "Pending");

        long result = db.insert("ORDERS", null, values);
        if (result == -1) {
            Log.e("DBHelper", "Failed to add order. Date: " + orderDate + ", Total: " + total + ", UserID: " + userId);
        }
        return result;
    }

    public boolean addOrderItems(long orderId, ArrayList<CartItem> cartItems) {
        SQLiteDatabase db = this.getWritableDatabase();
        boolean allInserted = true;

        for (CartItem item : cartItems) {
            ContentValues values = new ContentValues();
            values.put("O_ID", orderId);
            values.put("PID", item.getProductId());
            values.put("PRICE", item.getProductPrice());
            values.put("L_TOTAL", item.getProductPrice() * item.getQuantity());
            values.put("QUANTITY", item.getQuantity());

            long result = db.insert("ORDER_LIST", null, values);
            if (result == -1) {
                Log.e("DBHelper", "Failed to add order item for Product ID: " + item.getProductId());
                allInserted = false;
            }
        }
        return allInserted;
    }

    public Cursor getAllOrders() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT o.O_ID AS order_id, o.O_DATE AS order_date, o.STATUS AS order_status, " +
                "u.U_NAME AS customer_name, u.U_PHONE AS customer_phone " +
                "FROM ORDERS o " +
                "JOIN User u ON o.UID = u.U_ID";
        return db.rawQuery(query, null);
    }

    public Cursor getOrderDetailsWithProducts(int orderId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT o.O_ID AS order_id, o.O_DATE AS order_date, o.STATUS AS order_status, " +
                "u.U_NAME AS customer_name, u.U_PHONE AS customer_phone, " +
                "ol.QUANTITY, ol.L_TOTAL, " +
                "p.P_ID AS product_id, p.P_name AS product_name, p.P_price AS product_price, p.P_image AS product_image " +
                "FROM ORDERS o " +
                "JOIN User u ON o.UID = u.U_ID " +
                "JOIN ORDER_LIST ol ON o.O_ID = ol.O_ID " +
                "JOIN Product p ON ol.PID = p.P_ID " +
                "WHERE o.O_ID = ?";
        return db.rawQuery(query, new String[]{String.valueOf(orderId)});
    }


    public void updateOrderStatus(int orderId, String newStatus) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("STATUS", newStatus);
        db.update("ORDERS", values, "O_ID = ?", new String[]{String.valueOf(orderId)});
    }


    public Cursor getAllOrdersByUserId(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT O_ID AS _id, O_DATE, STATUS FROM ORDERS WHERE UID = ?",
                new String[]{String.valueOf(userId)});
    }

    public boolean addClip(String clipName, byte[] thumbnail, String video) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("C_NAME", clipName);
        values.put("C_THUMB", thumbnail);
        values.put("C_VIDEO", video);

        long result = db.insert("CLIP", null, values);
        db.close();

        if (result == -1) {
            Log.e("DBHelper", "Failed to add clip: " + clipName);
            return false;
        }
        return true;
    }

    public Cursor getAllClips() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM CLIP", null);
    }

    public Cursor getClipById(long clipId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(
                "CLIP",
                null,
                "C_ID = ?",
                new String[]{String.valueOf(clipId)},
                null,
                null,
                null
        );
    }
}
