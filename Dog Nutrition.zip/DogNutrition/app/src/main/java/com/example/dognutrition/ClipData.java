package com.example.dognutrition;

public class ClipData {
    private int id;
    private String title;
    private byte[] thumbnail;

    public ClipData(int id, String title, byte[] thumbnail) {
        this.id = id;
        this.title = title;
        this.thumbnail = thumbnail;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public byte[] getThumbnail() {
        return thumbnail;
    }
}

