package com.example.dognutrition;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.GridView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ViewProducts extends AppCompatActivity {

    GridView gridView;
    ArrayList<Food> list;
    FoodListAdapter adapter;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_products);

        gridView = findViewById(R.id.Grid);
        list = new ArrayList<>();
        adapter = new FoodListAdapter(this, R.layout.food_list, list);
        gridView.setAdapter(adapter);

        db = new DBHelper(this);
        loadProductsFromDatabase();


        gridView.setOnItemClickListener((parent, view, position, id) -> {

            Food selectedFood = list.get(position);


            Intent intent = new Intent(ViewProducts.this, ProductDetails.class);


            intent.putExtra("PRODUCT_ID", selectedFood.getPID());


            startActivity(intent);
        });
    }

    private void loadProductsFromDatabase() {
        Cursor cursor = db.getProductDetails();
        list.clear();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex("P_ID"));
                String name = cursor.getString(cursor.getColumnIndex("P_name"));
                String price = "Rs. " + cursor.getString(cursor.getColumnIndex("P_price"));
                byte[] image = cursor.getBlob(cursor.getColumnIndex("P_image"));

                list.add(new Food(id, name, price, image));
                Log.d("ViewProducts", "Loaded product: " + name + " - " + price);
            } while (cursor.moveToNext());
            cursor.close();
        } else {
            Toast.makeText(this, "No products found in the database.", Toast.LENGTH_SHORT).show();
            Log.d("ViewProducts", "No products found in the database.");
        }
        adapter.notifyDataSetChanged();
    }
}
