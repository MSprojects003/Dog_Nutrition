package com.example.dognutrition;

import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ClipListAdapter extends RecyclerView.Adapter<ClipListAdapter.ClipViewHolder> {
    private List<ClipData> clipDataList;
    private OnClipClickListener clipClickListener;

    public ClipListAdapter(List<ClipData> clipDataList, OnClipClickListener clipClickListener) {
        this.clipDataList = clipDataList;
        this.clipClickListener = clipClickListener;
    }

    @Override
    public ClipViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_clip_list, parent, false);
        return new ClipViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ClipViewHolder holder, int position) {
        ClipData clipData = clipDataList.get(position);
        holder.bind(clipData, clipClickListener);
    }

    @Override
    public int getItemCount() {
        return clipDataList.size();
    }

    public static class ClipViewHolder extends RecyclerView.ViewHolder {
        private TextView clipTitle;
        private ImageView clipThumbnail;

        public ClipViewHolder(View itemView) {
            super(itemView);
            clipTitle = itemView.findViewById(R.id.clipName);
            clipThumbnail = itemView.findViewById(R.id.imageViewThumbnail);
        }

        public void bind(ClipData clipData, OnClipClickListener clipClickListener) {
            clipTitle.setText(clipData.getTitle());
            clipThumbnail.setImageBitmap(BitmapFactory.decodeByteArray(clipData.getThumbnail(), 0, clipData.getThumbnail().length));

            itemView.setOnClickListener(v -> clipClickListener.onClipClick(clipData.getId()));
        }
    }

    public interface OnClipClickListener {
        void onClipClick(int clipId);
    }
}
