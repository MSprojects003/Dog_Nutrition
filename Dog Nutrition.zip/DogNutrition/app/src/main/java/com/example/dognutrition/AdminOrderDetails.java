package com.example.dognutrition;

import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class AdminOrderDetails extends AppCompatActivity {

    private DBHelper dbHelper;
    private TextView orderDateTextView, TotalPrice, orderStatusTextView, customerNameTextView, customerPhoneTextView, orderIdTextView;
    private ListView listView;
    private int orderId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_order_details);

        dbHelper = new DBHelper(this);


        TotalPrice = findViewById(R.id.textView11);
        orderDateTextView = findViewById(R.id.textView18);
        orderStatusTextView = findViewById(R.id.textView19);
        customerNameTextView = findViewById(R.id.textView16);
        customerPhoneTextView = findViewById(R.id.phoneNumberTextView);
        orderIdTextView = findViewById(R.id.textView15);

        listView = findViewById(R.id.ListView);

        Button button15 = findViewById(R.id.button15);
        button15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateOrderStatusToDone();
            }
        });


        orderId = getIntent().getIntExtra("ORDER_ID", -1);

        if (orderId != -1) {
            loadOrderDetails(orderId);
            loadOrderProducts(orderId);
        } else {
            Log.e("AdminOrderDetails", "Invalid order ID.");
        }
    }

    private void updateOrderStatusToDone() {
        if (orderId != -1) {
            dbHelper.updateOrderStatus(orderId, "Done");

            Toast.makeText(this, "Order marked as done", Toast.LENGTH_SHORT).show();
        } else {
            Log.e("AdminOrderDetails", "Cannot update status. Invalid order ID.");
        }
    }

    private void loadOrderDetails(int orderId) {

        Cursor cursor = dbHelper.getOrderDetailsWithProducts(orderId);
        if (cursor != null && cursor.moveToFirst()) {
            String orderDate = cursor.getString(cursor.getColumnIndex("order_date"));
            String orderStatus = "Status    : " + cursor.getString(cursor.getColumnIndex("order_status"));
            String customerName = "Customer  : " + cursor.getString(cursor.getColumnIndex("customer_name"));
            String customerPhone = "Phone     : " + cursor.getString(cursor.getColumnIndex("customer_phone"));


            String formattedDate = formatDate(orderDate);


            orderDateTextView.setText("Order Date: " + formattedDate);
            orderStatusTextView.setText(orderStatus);
            customerNameTextView.setText(customerName);
            customerPhoneTextView.setText(customerPhone);


            orderIdTextView.setText("Order ID: " + orderId);

            cursor.close();
        } else {
            Log.e("AdminOrderDetails", "No data found for orderId: " + orderId);
        }
    }

    private String formatDate(String dateString) {
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        SimpleDateFormat outputFormat = new SimpleDateFormat("MMM, dd", Locale.getDefault());
        String formattedDate = "";

        try {
            Date date = inputFormat.parse(dateString);
            formattedDate = outputFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return formattedDate;
    }

    private void loadOrderProducts(int orderId) {
        Cursor cursor = dbHelper.getOrderDetailsWithProducts(orderId);
        ArrayList<HashMap<String, Object>> productList = new ArrayList<>();
        double totalp = 0.0;
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String productName = cursor.getString(cursor.getColumnIndex("product_name"));
                int quantity = cursor.getInt(cursor.getColumnIndex("QUANTITY"));
                double total = cursor.getDouble(cursor.getColumnIndex("L_TOTAL"));
                double productPrice = cursor.getDouble(cursor.getColumnIndex("product_price"));
                byte[] imageBytes = cursor.getBlob(cursor.getColumnIndex("product_image"));
                Bitmap productImage = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);


                HashMap<String, Object> product = new HashMap<>();
                product.put("product_name", productName);
                product.put("quantity", String.valueOf(quantity));
                product.put("total", String.format("%.2f", total)); // Format total price
                product.put("product_price", String.format("%.2f", productPrice)); // Format product price
                product.put("product_image", productImage);


                productList.add(product);

                totalp += total;
            } while (cursor.moveToNext());

            cursor.close();


            ProductOrderAdapter adapter = new ProductOrderAdapter(this, productList);
            listView.setAdapter(adapter);

            TotalPrice.setText("Total Price: " + String.format("%.2f", totalp));
        } else {
            Log.e("AdminOrderDetails", "No products found for the given orderId: " + orderId);
        }
    }
}
