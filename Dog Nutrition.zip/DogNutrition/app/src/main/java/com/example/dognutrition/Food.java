package com.example.dognutrition;

public class Food {
    private int PID;
    private String Pname;
    private String Pprice;
    private byte[] Pimage;

    public Food(int PID, String pname, String pprice, byte[] pimage) {
        this.PID = PID;
        Pname = pname;
        Pprice = pprice;
        Pimage = pimage;
    }

    public int getPID() {
        return PID;
    }

    public void setPID(int PID) {
        this.PID = PID;
    }

    public String getPname() {
        return Pname;
    }

    public void setPname(String pname) {
        Pname = pname;
    }

    public String getPprice() {
        return Pprice;
    }

    public void setPprice(String pprice) {
        Pprice = pprice;
    }

    public byte[] getPimage() {
        return Pimage;
    }

    public void setPimage(byte[] pimage) {
        Pimage = pimage;
    }
}
